#pragma once

#pragma comment (lib, "opengl32.lib")
#pragma comment (lib, "glu32.lib")
#pragma comment (lib, "glaux.lib")

#include "OpenGL/gltools.h"
#include "OpenGL/GLFrame.h"

