#pragma once

#include "OGL_Includes.h"
#include "vec3.h"

#define VERTICES			3
#define	OGL_GEOMETRY_TYPE	GL_TRIANGLES

struct MC_Geometry
{
	int		VertexID[VERTICES];
};

struct MC_Vertex
{
	vec3f	Position;
	vec3f	Normal;
};

class MapController
{
private:
	bool			Active;

	GLuint			DL_Geometry;
	GLuint			DL_Lines;
	GLuint			DL_Normals;

	int				VertexCount;
	MC_Vertex*		Vertices;

	int				GeometryCount;
	MC_Geometry*	Geometry;

	float 			X_Lowest;
	float 			X_Highest;
	float 			X_Length;
	float 			Z_Lowest;
	float 			Z_Highest;
	float 			Z_Length;



public:
	MapController(char* MapFile);
	~MapController(void);

	void RenderList(void);

};
