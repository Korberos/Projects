#pragma once

#include "OGL_Includes.h"

bool LoadAndBindBMP(char *Filename, GLuint* Texture);