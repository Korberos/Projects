#pragma once

#include "OGL_Includes.h"
#include "vec3.h"

#define VERTICES 3

struct MC_Geometry
{
	vec3f	Vertex[VERTICES];
	vec3f	Normal;
};

class MapController
{
private:
	bool			Active;

	GLuint			DL_Geometry;
	GLuint			DL_Lines;
	GLuint			DL_Normals;

	int				GeometryCount;
	MC_Geometry*	Geometry;

	float 			X_Lowest;
	float 			X_Highest;
	float 			X_Length;
	float 			Z_Lowest;
	float 			Z_Highest;
	float 			Z_Length;



public:
	MapController(char* MapFile);
	~MapController(void);

	void RenderList(void);
	void RenderStatic(void);

};
