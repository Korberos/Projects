#include "MapController.h"

#include <fstream>
using namespace std;

#define KEYDOWN(key) ((GetAsyncKeyState(key) & 0x8000) ? true : false)

MapController::MapController(char* MapFile)
{
	// Open the map file, checking if it is successful
	fstream File(MapFile, ios_base::binary|ios_base::in);
	if ((File.bad()) || (!File.good()))
	{
		Active		= false;
		Geometry	= 0;
		File.close();
		return;
	}
	Active = true;

	// Check how many rows and columns there will be
	File.read((char*)&GeometryCount, sizeof(int));

	// Allocate all memory needed and set default numbers
	Geometry = new MC_Geometry[GeometryCount];
	for (int i = 0; i < GeometryCount; i += 1)
	{
		for (int j = 0; j < VERTICES; j += 1)
		{
			Geometry[i].Vertex[j].x = 1234.5678f;
			Geometry[i].Vertex[j].y = 1234.5678f;
			Geometry[i].Vertex[j].z = 1234.5678f;
		}
		Geometry[i].Normal = 1234.5678f;
	}

	// Read in all values, find the highest and lowest for X and Z
	X_Lowest	= 1234.5678f;
	X_Highest	= 1234.5678f;
	Z_Lowest	= 1234.5678f;
	Z_Highest	= 1234.5678f;

	for (int i = 0; ((i < GeometryCount) && (!File.eof())); i += 1)
	{
		for (int j = 0; j < VERTICES; j += 1)
		{
			// Read in the triangle vertices
			File.read((char*)&Geometry[i].Vertex[j].x, sizeof(float));
			File.read((char*)&Geometry[i].Vertex[j].y, sizeof(float));
			File.read((char*)&Geometry[i].Vertex[j].z, sizeof(float));

			// Check for highest and lowest points on the X and Z axis
			if ((Geometry[i].Vertex[j].x > X_Highest)	|| (X_Highest == 1234.5678f))	X_Highest	= Geometry[i].Vertex[j].x;
			if ((Geometry[i].Vertex[j].x < X_Lowest)	|| (X_Lowest == 1234.5678f))	X_Lowest	= Geometry[i].Vertex[j].x;
			if ((Geometry[i].Vertex[j].z > Z_Highest)	|| (Z_Highest == 1234.5678f))	Z_Highest	= Geometry[i].Vertex[j].z;
			if ((Geometry[i].Vertex[j].z < Z_Lowest)	|| (Z_Lowest == 1234.5678f))	Z_Lowest	= Geometry[i].Vertex[j].z;

			// Calculate the normal of the triangle		
			cross_product(Geometry[i].Normal, (Geometry[i].Vertex[2] - Geometry[i].Vertex[0]), (Geometry[i].Vertex[1] - Geometry[i].Vertex[0]));
			Geometry[i].Normal.normalize();
		}
	}

	X_Length	= X_Highest - X_Lowest;
	Z_Length	= Z_Highest - Z_Lowest;

	// Create a draw list allocation for each list
	DL_Geometry		= glGenLists(2);
	DL_Lines		= DL_Geometry + 1;
	DL_Normals		= DL_Lines + 1;

	// Create the DL_Squares list (All Quads)
	glNewList(DL_Geometry, GL_COMPILE);
		glBegin(GL_TRIANGLES);
			for (int i = 0; i < GeometryCount; i += 1)
			{
				glNormal3f(Geometry[i].Normal.x, Geometry[i].Normal.y, Geometry[i].Normal.z);
				for (int j = 0; j < VERTICES; j += 1)
				{
					glTexCoord2d((Geometry[i].Vertex[j].z - Z_Lowest) / Z_Length, (Geometry[i].Vertex[j].x - X_Lowest) / X_Length);
					glVertex3f(Geometry[i].Vertex[j].x, Geometry[i].Vertex[j].y, Geometry[i].Vertex[j].z);
				}
			}
		glEnd();
	glEndList();

	// Create the DL_Lines list (All Lines)
	glNewList(DL_Lines, GL_COMPILE);
		glBegin(GL_LINES);
			for (int i = 0; i < GeometryCount; i += 1)
			{
				for (int j = 0; j < VERTICES; j += 1)
				{
					glVertex3f(Geometry[i].Vertex[j].x, Geometry[i].Vertex[j].y, Geometry[i].Vertex[j].z);
					glVertex3f(Geometry[i].Vertex[(j+1)%VERTICES].x, Geometry[i].Vertex[(j+1)%VERTICES].y, Geometry[i].Vertex[(j+1)%VERTICES].z);
				}
			}
		glEnd();
	glEndList();

	// Create the DL_Normals list (A normal for each triangle)
	glNewList(DL_Normals, GL_COMPILE);
		glBegin(GL_LINES);
			for (int i = 0; i < GeometryCount; i += 1)
			{
				vec3f NormalTest;
				NormalTest.x = (Geometry[i].Vertex[0].x + Geometry[i].Vertex[1].x + Geometry[i].Vertex[2].x) / 3.0f;
				NormalTest.y = (Geometry[i].Vertex[0].y + Geometry[i].Vertex[1].y + Geometry[i].Vertex[2].y) / 3.0f;
				NormalTest.z = (Geometry[i].Vertex[0].z + Geometry[i].Vertex[1].z + Geometry[i].Vertex[2].z) / 3.0f;
					
				glVertex3f(NormalTest.x, NormalTest.y, NormalTest.z);
				glVertex3f(NormalTest.x + Geometry[i].Normal.x, NormalTest.y + Geometry[i].Normal.y, NormalTest.z + Geometry[i].Normal.z);
			}
		glEnd();
	glEndList();

	File.close();
}

MapController::~MapController(void)
{
	// Free all allocated memory
	if (Active == true)
	{
		glDeleteLists(DL_Geometry, 2);
		delete [] Geometry;
	}
}

void MapController::RenderList(void)
{
	if (Active == false) return;

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glCallList(DL_Geometry);

	if (KEYDOWN(VK_LSHIFT))
	{
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);
		glLineWidth(2);
		glColor4f(0.4f, 0.4f, 1.0f, 1.0f);
		glCallList(DL_Lines);
	}

	if (KEYDOWN(VK_SPACE))
	{
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);
		glLineWidth(2);
		glColor4f(0.6f, 0.6f, 0.2f, 1.0f);
		glCallList(DL_Normals);
	}
}

void MapController::RenderStatic(void)
{
	if (Active == false) return;

	glEnable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLES);
		for (int i = 0; i < GeometryCount; i += 1)
		{
			glNormal3f(Geometry[i].Normal.x, Geometry[i].Normal.y, Geometry[i].Normal.z);
			for (int j = 0; j < VERTICES; j += 1)
			{
				glTexCoord2d((Geometry[i].Vertex[j].z - Z_Lowest) / Z_Length, (Geometry[i].Vertex[j].x - X_Lowest) / X_Length);
				glVertex3f(Geometry[i].Vertex[j].x, Geometry[i].Vertex[j].y, Geometry[i].Vertex[j].z);
			}
		}
	glEnd();

	if (KEYDOWN(VK_LSHIFT))
	{
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);
		glLineWidth(2);
		glColor4f(0.4f, 0.4f, 1.0f, 1.0f);
		glBegin(GL_LINES);
			for (int i = 0; i < GeometryCount; i += 1)
			{
				for (int j = 0; j < VERTICES; j += 1)
				{
					glVertex3f(Geometry[i].Vertex[j].x, Geometry[i].Vertex[j].y, Geometry[i].Vertex[j].z);
					glVertex3f(Geometry[i].Vertex[(j+1)%VERTICES].x, Geometry[i].Vertex[(j+1)%VERTICES].y, Geometry[i].Vertex[(j+1)%VERTICES].z);
				}
			}
		glEnd();
	}

	if (KEYDOWN(VK_SPACE))
	{
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);
		glLineWidth(2);
		glColor4f(0.6f, 0.6f, 0.2f, 1.0f);
		glBegin(GL_LINES);
			for (int i = 0; i < GeometryCount; i += 1)
			{
				vec3f NormalTest;
				NormalTest.x = (Geometry[i].Vertex[0].x + Geometry[i].Vertex[1].x + Geometry[i].Vertex[2].x) / 3.0f;
				NormalTest.y = (Geometry[i].Vertex[0].y + Geometry[i].Vertex[1].y + Geometry[i].Vertex[2].y) / 3.0f;
				NormalTest.z = (Geometry[i].Vertex[0].z + Geometry[i].Vertex[1].z + Geometry[i].Vertex[2].z) / 3.0f;
					
				glVertex3f(NormalTest.x, NormalTest.y, NormalTest.z);
				glVertex3f(NormalTest.x + Geometry[i].Normal.x, NormalTest.y + Geometry[i].Normal.y, NormalTest.z + Geometry[i].Normal.z);
			}
		glEnd();
	}
}